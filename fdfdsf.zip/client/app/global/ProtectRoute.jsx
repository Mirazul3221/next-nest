"use client"
import { useRouter } from "next/navigation";
import storeContext from "@/app/global/createContex"
import { useContext } from "react"

const ProtectRoute = ({children}) => {
  const { store } = useContext(storeContext)
  const router = useRouter();
    if (store?.userInfo?.id) {
      return children  
    } else {
      router.push("/register")
    }
}

export default ProtectRoute
