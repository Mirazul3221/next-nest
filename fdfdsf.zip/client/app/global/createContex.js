"use client"
import { createContext } from "react";

const storeContext = createContext();
export default storeContext