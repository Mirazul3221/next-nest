"use client";
// import { useRouter } from "next/navigation";
import { useContext, useEffect, useState } from "react";
import CustomTimer from "./mainpage_components/timer";
import Roboticx from "./mainpage_components/robotix";
import Navbar from "./components/Navbar";
import storeContext from "./global/createContex";
import UserDashboard from "./userdashboard/UserDashboard";
import AdminDashboard from "./admindashboard/AdminDashboard";
import AssistantHome from "./assistantdashboard/Home";
export default function Home() {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);
  const { store } = useContext(storeContext);
  const otp = Math.floor(1000 + Math.random() * 9000);
  if (store?.userInfo?.role === "user") {
    return <div>{isClient ? <UserDashboard /> : ""}</div>;
  } else if (store?.userInfo?.role === "admin") {
    return <div>{isClient ? <AdminDashboard /> : ""}</div>;
  } else if (store?.userInfo?.role === "assistant") {
    return <div>{isClient ? <AssistantHome /> : <></>}</div>;
  } else {
    return (
      <div>
        {isClient ? (
          <main className="overflow-x-hidden max-w-[1440px] mx-auto">
            <Navbar />
            <div className="fixed transform left-[50%] -translate-x-[50%] -z-10 mt-16 mx-auto">
              <div>
                <CustomTimer />
                <Roboticx />
              </div>
            </div>
            {/* <div className="w-screen h-screen mt-[100vh] bg-white"></div>
            <div className="w-screen h-screen bg-red-100"></div> */}
          </main>
        ) : (
          <></>
        )}
      </div>
    );
  }
}
