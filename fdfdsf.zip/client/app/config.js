

// export const baseurl = 'https://sghkssnlssfneroeribjsfavhststjshhfsemsrhcesgeds-beige.vercel.app'
export const baseurl = 'http://localhost:5050'