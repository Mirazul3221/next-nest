import React from 'react'
import ProtectRoute from '../global/ProtectRoute'



const page = () => {
  return (
    <div>
       <ProtectRoute>
        Helo
       </ProtectRoute>
    </div>
  )
}

export default page
