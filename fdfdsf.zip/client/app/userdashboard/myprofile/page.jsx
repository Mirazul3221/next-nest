"use client";
import React, { useState, useContext, useEffect } from "react";
import Navbar from "../components/Navbar";
import Profile from "@/app/components/Profile";
import axios from "axios";
import storeContext from "@/app/global/createContex";
import { PiPenLight } from "react-icons/pi";
import { baseurl } from "@/app/config";
import Image from "next/image";

const Page = () => {
  const [controltitle, setControlTitle] = useState(false);
  const [controlDesc, setControlDesc] = useState(false);
  const [updateTittle, setUpdateTittle] = useState("");
  const [updateDesc, setUpdateDesc] = useState("");

  const [userDetails, setUserDetails] = useState({
    name: "",
    email: "",
    title: "",
  });

  const { store } = useContext(storeContext);
  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(`${baseurl}/auth/find`, {
          headers: {
            Authorization: `Bearer ${store.token}`,
          },
        });
        setUserDetails({ ...userDetails, ...data });
      } catch (error) {
        console.log(error);
      }
    }
    fetchData();
  }, [controltitle,controlDesc,store.token,userDetails]);

  //========================================
  const titleValue = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`${baseurl}/auth/update`, updateTittle, {
        headers: {
          Authorization: `Bearer ${store.token}`,
        },
      });
      setControlTitle(false);
    } catch (error) {}
  };

  //=========================================
  const descriptionValue = async (e) => {
    e.preventDefault();
    try {
      await axios.patch(`${baseurl}/auth/update`, updateDesc, {
        headers: {
          Authorization: `Bearer ${store.token}`,
        },
      });
      setControlDesc(false);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div className="">
      <Navbar />
      <div className="md:w-4/12 border-t-4 rounded-lg border-blue-600 ml-2 shadow-md p-10">
        <div className="w-1/2 mx-auto py-2">
          <Profile />
          <h1 className="text-center text-2xl font-semibold">
            {userDetails.name}
          </h1>
        </div>
        <div className="border-t-2 py-2">
          {controltitle ? (
            <>
              <form onSubmit={titleValue}>
                <input
                  className="border-2 w-full px-2 py-[3px]"
                  type="text"
                  onChange={(e) => {
                    setUpdateTittle({ title: e.target.value });
                  }}
                  // value={userDetails.title}
                  placeholder="Update your title"
                />
                <button
                  type="submit"
                  className="text-white mt-2 bg-blue-600 hover:bg-blue-700 duration-500 py-[3px] rounded-md w-full">
                  Submit
                </button>
              </form>
            </>
          ) : (
            <>
              <div className="relative w-full group">
                <h2 className={`${userDetails.title?.length  <= 30 ? "text-center text-green-500" : "text-rose-500"} `}>{userDetails.title?.length  <= 0 ? "Untitled User" : userDetails.title}</h2>
                <div
                  onClick={() => setControlTitle(true)}
                  className="group-hover:flex hidden bg-white w-5 h-5 cursor-pointer rounded-full absolute right-0 top-0 justify-center items-center shadow-md">
                    <PiPenLight/>
                  </div>
              </div>
            </>
          )}
        </div>

        <div className="mt-3">
          {controlDesc ? (
            <>
              <form onSubmit={descriptionValue}>
                <textarea
                  className="w-full border-[1px] p-2"
                  onChange={(e) =>
                    setUpdateDesc({ description: e.target.value })
                  }
                  rows="5"
                  placeholder="Update description"
                  name="text"
                  id=""></textarea>
                <button
                  type="submit"
                  className="text-white mt-2 bg-blue-600 hover:bg-blue-700 duration-500 py-[3px] rounded-md w-full">
                  Submit
                </button>
              </form>
            </>
          ) : (
            <>
              <div className="relative w-full group">
                <p className="text-justify">{userDetails.description?.length <= 0? "Write Something about you." : userDetails.description}</p>
                <div
                  onClick={() => setControlDesc(true)}
                  className="group-hover:flex hidden bg-white w-8 h-8 cursor-pointer rounded-full absolute right-0 top-0 justify-center items-center shadow-md">
                     <PiPenLight size={22}/>
                  </div>
              </div>
            </>
          )}
        </div>
      </div>
      <Image src={userDetails.Profile} alt="sdfa" />
      <h2>{userDetails.profile}</h2>
    </div>
  );
};

export default Page;
