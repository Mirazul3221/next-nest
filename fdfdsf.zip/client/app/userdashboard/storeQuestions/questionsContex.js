import { createContext } from "react";

const questionsContext = createContext();

export default questionsContext;
