import Image from 'next/image'
import React from 'react'
import logo from "@/public/bcs-logo.png"
const Logo = () => {
  return (
    <div>
        <Image src={logo} alt='BCS Logo'/>
    </div>
  )
}

export default Logo
