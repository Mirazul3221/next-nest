"use client";
import Link from "next/link";
import React from "react";

const Navbar = () => {
  return (
    <div>
      <div className="w-full py-3 shadow-md fixed top-0 bg-white left-0">
        <ul className="lg:w-11/12 md:w-full mx-auto flex justify-center">
          <li className="text-lg font-normal px-4 py-[4px] hover:bg-slate-100 hover:border-gray-200 text-gray-700 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-white">
            About Us
          </li>
          <li className="text-lg font-normal px-4 py-[4px] hover:bg-slate-100 hover:border-gray-200 text-gray-700 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-white">
            Our Team
          </li>
          <li className="text-lg font-normal px-4 py-[4px] hover:bg-slate-100 hover:border-gray-200 text-gray-700 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-white">
            Service
          </li>
          <li className="text-lg font-normal px-4 py-[4px] hover:bg-slate-100 hover:border-gray-200 text-gray-700 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-white">
            Blogs
          </li>
          <li className="text-lg font-normal px-4 py-[4px] hover:bg-slate-100 hover:border-gray-200 text-gray-700 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-white">
            BCS corner
          </li>
          <li className="text-lg font-normal px-4 py-[4px] hover:bg-slate-100 hover:border-gray-200 text-gray-700 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-white">
            Recent News
          </li>
          <li className="text-lg font-normal px-4 py-[4px] hover:bg-slate-100 hover:border-gray-200 text-gray-700 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-white">
            Job Circular
          </li>
          <li className="text-lg font-normal px-4 py-[4px] hover:bg-slate-100 hover:border-gray-200 text-gray-700 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-white">
            Contact Info
          </li>
          <Link href={"/register"}>
            <li className="text-lg font-normal px-4 py-[4px] ml-2 hover:text-white hover:bg-green-500 text-green-500 w-fit cursor-pointer duration-500 rounded-md border-[1px] border-green-500">
              Join
            </li>
          </Link>
        </ul>
      </div>
    </div>
  );
};

export default Navbar;
