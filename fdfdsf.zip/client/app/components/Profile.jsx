"use client";
import React, { useEffect, useState } from "react";
import profile from "@/public/profile.png";
import Image from "next/image";
import { ImCamera } from "react-icons/im";
import axios from "axios";
import { baseurl } from "../config";
// import storeContext from '../global/createContex'
const Profile = () => {
  const [image, setImage] = useState();
  const [imageUrl, setImageUrl] = useState('');
  const [isUpload, setIsUpload] = useState(false);
  // const { store } = useContext(storeContext)
  const imageHandler = (e) => {
    if (e.target.files.length > 0) {
      setImage(e.target.files[0]);
      setImageUrl(URL.createObjectURL(e.target.files[0]));
    }
  };
  useEffect(() => {
    console.log(imageUrl);
  }, [imageUrl]);
  const UploadProfilelImage =async (e) => {
    e.preventDefault()
    try {
     const {data} = await axios.post(`${baseurl}/auth/upload`,{file:image})
     setIsUpload(false)
     console.log(data)
    } catch (error) {
      console.log(error)
    }
  };
  return (
    <div className="">
      <div className="flex flex-col items-center w-fit relative group">
        {imageUrl.length > 0 ? (
          <Image
            className="w-[115px] h-[115px] md:w-[180px] border-4 md:h-[180px] rounded-full"
            src={imageUrl}
            alt="profile-image"
          />
        ) : (
          <Image src={profile} alt="bffd" />
        )}
        <label
          htmlFor="imageUpload"
          onClick={()=> {
            setTimeout(() => {
              setIsUpload(true)
            }, 3000);
          }}
          className="absolute w-full h-full rounded-full bg-black/50 duration-100 cursor-pointer flex justify-center items-center scale-0 group-hover:scale-100">
          <ImCamera color="white" size={50} />
        </label>
        {/* <img src={image} alt="image" /> : <img src={profile} alt="image" /> */}
        {/* <h2 className='text-[12px]'>{store.userInfo.name}</h2> */}
      </div>
      <form className="w-full flex justify-center" onSubmit={UploadProfilelImage}>
        <input
          id="imageUpload"
          onChange={imageHandler}
          className=" py-[5px] hidden border-[1px] w-52 px-2 rounded-md focus:border-sky-500 duration-300"
          type="file"
        />
        {isUpload ? <button className="bg-blue-500 text-sm px-4 w-fit mx-auto text-white py-[2px] rounded-md my-2" type="submit">Upload</button> : ""}
      </form>
    </div>
  );
};

export default Profile;
