"use client";
import axios from "axios";
import React, { useContext, useState } from "react";
import logo from '@/public/bcs-logo.png'
import { useRouter } from "next/navigation";
import storeContext from "../global/createContex";
import { baseurl } from "../config";
import { FaRegEyeSlash } from "react-icons/fa";
import { IoEyeOutline } from "react-icons/io5";
import Image from "next/image";
const InputForm = () => {
  //get userinfo from global data====================
  const { dispatch } = useContext(storeContext);
  const router = useRouter();
  const [alert, setAlert] = useState("");
  const [submitValue, setSubmitValue] = useState({
    email: "",
    password: "",
  });

  const [showPassword, setShowPassword] = useState(false);

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const targetElement = (e) => {
    setSubmitValue({
      ...submitValue,
      [e.target.name]: e.target.value,
    });
  };
  const handlesubmit = async (e) => {
    e.preventDefault();

    // redirect("/dashboard")
    try {
      let uri = `${baseurl}/auth/user/login`;
      const { data } = await axios.post(uri, submitValue);
      setAlert(data.msg);
      // if(typeof window !== 'undefined'){
      //   // now access your localStorage

      // }

      localStorage.setItem("token", data.token);

      dispatch({ type: "login_success", paylod: { token: data.token } });
      setTimeout(() => {
        router.push("/");
      }, 1000);
    } catch (error) {
      console.log(error);
      setAlert(error.response?.data.message);
    }
  };
  //  async function request () {
  //   const { data } =await axios.get("http://localhost:5050/auth/request");
  //   console.log(data)
  //  }
  ////  request ()
  return (
    <div>
      <div className="p-8 md:w-[400px] md:h-[74vh]">
        <form onSubmit={handlesubmit}>
          <div>
            <Image className="w-32 mx-auto mb-8" src={logo} alt="logo"/>
            <h2 className={`text-rose-300`}>{alert}</h2>
            <div className="">
              <label
                htmlFor="email"
                className="block text-sm font-medium text-gray-900 dark:text-white">
                Email address
              </label>
              <input
                onChange={targetElement}
                value={submitValue.email}
                type="email"
                id="email"
                name="email"
                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:bg-white focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                placeholder="john.doe@company.com"
                required
              />
            </div>
            <div className="mb-2">
              {/* <label
                htmlFor="password"
                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                Password
              </label>
              <input
                onChange={targetElement}
                value={submitValue.password}
                type="password"
                id="password"
                name="password"               
                placeholder="•••"
                required
              /> */}

              <label
                htmlFor="email"
                className="block mt-4 text-sm font-medium text-gray-900 dark:text-white">
                Password
              </label>

              <div className="bg-gray-50 relative border border-gray-300 text-gray-900 text-sm rounded-lg">
                <input
                  className="focus:ring-blue-500 rounded-lg pr-12 focus:outline-none focus:bg-white focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  type={showPassword ? "text" : "password"}
                  placeholder="•••••••••"
                  id="password"
                  name="password"
                  value={submitValue.password}
                  onChange={targetElement}
                />
                <div
                  onClick={toggleShowPassword}
                  className="focus:outline-none cursor-pointer p-2 rounded-full mr-4 absolute top-[50%] transform -translate-y-[50%] right-0">
                  {showPassword ? <FaRegEyeSlash /> : <IoEyeOutline />}
                </div>
              </div>
            </div>
            <button
              type="submit"
              className="text-white mt-2 bg-blue-600 hover:bg-blue-700 duration-500 py-2 rounded-md w-full">
              Submit
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default InputForm;
