import Image from 'next/image'
import React from 'react'

const TopBar = () => {
  return (
    <div className='py-4 px-20 mx-10 bg-white flex justify-between items-center'>
      <Image className='w-28' src='./bcs-logo.png' alt="gserees"/>
         <h2>Admin</h2>
    </div>
  )
}

export default TopBar
