import React from 'react'
import QuestionAddForm from './components/QuestionAddForm'
import Logo from '../components/Logo'

const AssistantHome = () => {
  return (
    <div>
      <div className="top px-10 bg-gray-200 py-4"><div className="w-28"> <Logo/></div></div>
      <div className="flex"><div className="p-10 bg-gray-200 h-screen w-2/12">Side bar</div><QuestionAddForm/></div>
    </div>
  )
}

export default AssistantHome
