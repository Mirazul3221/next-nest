"use client";
import {englishTopicValue, examTypeValue } from "@/app/assistantdashboard/components/data";
import Logo from "@/app/components/Logo";
import Navbar from "@/app/userdashboard/components/Navbar";
import Link from "next/link";
import React, { useState } from "react";

const Page = () => {
  const [navValue, setNaveValue] = useState("home");
  console.log(navValue);
  return (
    <div className="md:px-10 px-4">
      <div className="flex justify-between items-center">
        <div className="md:w-20 w-16">
          <Link href="/">
            {/* <Image src={logo} alt="bffd" /> */}
            <Logo />
          </Link>
        </div>
        <Navbar value={navValue} setValue={setNaveValue} />
      </div>

      <div className="md:flex justify-between gap-4">
        <div className="md:w-1/2">
          <h2 className="py-2 bg-green-400 px-6">Exam</h2>
          <h3 className="py-2 my-2 bg-gray-700 text-white duration-200 px-6 cursor-pointer font-bold">
              Bcs Question
            </h3>
            {examTypeValue.bcs.map((lite,i) => {
              return (
                <h3 key={i} className="py-2 my-2 bg-gray-50 shadow-sm hover:bg-gray-700 hover:text-white duration-200 px-6 cursor-pointer">
                  {lite}
                </h3>
              );
            })}
          <h3 className="py-2 my-2 bg-gray-700 text-white duration-200 px-6 cursor-pointer font-bold">
          university Question
            </h3>
            {examTypeValue.university.map((lite,i) => {
              return (
                <h3 key={i} className="py-2 my-2 hover:bg-gray-700 bg-gray-50 shadow-sm hover:text-white duration-200 px-6 cursor-pointer">
                  {lite}
                </h3>
              );
            })}
        </div>
        <div className="md:w-1/2">
          <h2 className="py-2 bg-green-400 px-6">Topic</h2>
          <div className="topic_list">
            <h3 className="py-2 my-2 bg-gray-700 shadow-sm text-white duration-200 px-6 cursor-pointer font-bold">
              Literature
            </h3>
            {englishTopicValue.literature.map((lite,i) => {
              return (
                <h3 key={i} className="py-2 my-2 bg-gray-50 shadow-sm hover:bg-gray-700 hover:text-white duration-200 px-6 cursor-pointer">
                  {lite}
                </h3>
              );
            })}
            <h3 className="py-2 my-2 bg-gray-700 text-white duration-200 px-6 cursor-pointer font-bold">
              Grammer
            </h3>
            {englishTopicValue.grammer.map((lite,i) => {
              return (
                <h3 key={i} className="py-2 my-2 bg-gray-50 shadow-sm hover:bg-gray-700 hover:text-white duration-200 px-6 cursor-pointer">
                  {lite}
                </h3>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page;
