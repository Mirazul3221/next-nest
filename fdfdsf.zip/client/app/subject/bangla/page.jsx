"use client";
import {
  banglaTopicValue01,
  examTypeValue,
} from "@/app/assistantdashboard/components/data";
import { IoArrowBackCircleOutline } from "react-icons/io5";
import Logo from "@/app/components/Logo";
import { baseurl } from "@/app/config";
import storeContext from "@/app/global/createContex";
import Monitor from "@/app/userdashboard/components/examonitor/Monitor";
// import Navbar from "@/app/userdashboard/components/Navbar";
import axios from "axios";
import Link from "next/link";
import React, { useContext, useEffect, useState } from "react";
import "../../userdashboard/components/cssfiles/marksmcq.css"
const Page = () => {
  // const [navValue, setNaveValue] = useState("home");
  const [title, setTitle] = useState("");
  const [headTitle, setHedTitle] = useState("");
  const [getTopicValue, setGetTopicValue] = useState("");
  const [switcher, setSwitcher] = useState(false);
  //==============API====================
  const { store } = useContext(storeContext);
  const [data, setData] = useState(null);
  useEffect(() => {
    async function fetchData() {
      try {
        const { data } = await axios.get(`${baseurl}/bangla/find`, {
          headers: {
            Authorization: `Bearer ${store.token}`,
          },
        });

        setData(data);
      } catch (error) {
        console.log(error);
      }
    }
    fetchData();
  }, [store.token]);

  const filterValue = (val) => {
    const returnFilterValue = data?.filter((question) => {
      return question.topic === val;
    });
    return returnFilterValue;
  };
  const filterData = filterValue(getTopicValue);

  console.log(getTopicValue);
  //==============End API====================
  return (
    <div className="md:px-10 px-4">
      <div className="flex justify-between items-center">
        <div className="md:w-20 w-16">
          <Link href="/">
            {/* <Image src={logo} alt="bffd" /> */}
            <Logo />
          </Link>
        </div>
        {/* <Navbar value={navValue} setValue={setNaveValue} /> */}
      </div>

      {switcher ? (
       <>{filterData?.length > 0 ? <Monitor questions={filterData} /> : "gfkj"}</>
      ) : (
        <div className="md:flex justify-between gap-4">
          <div className="md:w-1/2">
            <h2 className="py-2 bg-fuchsia-500 px-6 text-2xl md:text-3xl text-white">
              বিষয় ভিত্তিক
            </h2>
            <div className="gap-[5px]">
              {banglaTopicValue01.map((item) => {
                return (
                  <>
                    <div className="w-full">
                      <h2
                        onClick={() => {
                          headTitle !== item.mainTitle
                            ? setHedTitle(item.mainTitle)
                            : setHedTitle("");
                          setTitle("");
                        }}
                        className="py-2 px-6 font-bold md:text-lg text-gray-700 md:border mt-[5px] cursor-pointer">
                        {item.mainTitle}
                      </h2>
                      {item.mainTitle === headTitle && (
                        <div>
                          {item.subTitleName?.map((item2) => {
                            return (
                              <>
                                <h3
                                  onClick={() =>
                                    title !== item2.name
                                      ? setTitle(item2.name)
                                      : setTitle("")
                                  }
                                  className={` py-2 cursor-pointer px-6 ml-6 md:ml-12 border shadow-sm text-gray-600 mt-[5px]`}>
                                  {item2.name}
                                </h3>
                                {title == item2.name && (
                                  <div>
                                    {item2.topic.map((item3,i) => {
                                      return (
                                        <h3 key={i}
                                          onClick={() => {
                                            setGetTopicValue(item3);
                                            setSwitcher(true);
                                          }}
                                          className={`${
                                            title.length > 0
                                              ? "block"
                                              : "hidden"
                                          } py-1 pl-6 text-gray-500 hover:bg-gray-100 duration-100 text-sm ml-10 md:ml-20 mb-2 border mt-[3px] cursor-pointer`}>
                                          {item3}
                                        </h3>
                                      );
                                    })}
                                  </div>
                                )}
                              </>
                            );
                          })}
                        </div>
                      )}
                    </div>
                    {/* <div className="">
                      {item.subTitleName.map((item)=>{
                        <h2>{item.name}</h2>
                      })}
                    </div> */}
                  </>
                );
              })}
            </div>
            <div className="topic_list">
            </div>
          </div>
          <div className="md:w-1/2">
            <h2 className="py-2 bg-green-400 px-6">Exam</h2>
            <h3 className="py-2 my-2 bg-gray-700 text-white duration-200 px-6 cursor-pointer font-bold">
              Bcs Question
            </h3>
            {examTypeValue.bcs.map((lite,i) => {
              return (
                <h3 key={i} className="py-2 my-2 bg-gray-50 shadow-sm hover:bg-gray-700 hover:text-white duration-200 px-6 cursor-pointer">
                  {lite}
                </h3>
              );
            })}
            <h3 className="py-2 my-2 bg-gray-700 text-white duration-200 px-6 cursor-pointer font-bold">
              university Question
            </h3>
            {examTypeValue.university.map((lite,i) => {
              return (
                <h3 key={i} className="py-2 my-2 hover:bg-gray-700 bg-gray-50 shadow-sm hover:text-white duration-200 px-6 cursor-pointer">
                  {lite}
                </h3>
              );
            })}
          </div>
        </div>
      )}
     {switcher &&  <div onClick={()=>setSwitcher(false)} className="bg-gray-200/50 cursor-pointer shadow-lg px-2 md:px-6 py-[3px] md:py-2 rounded-md w-fit fixed bottom-4 right-4 back_bounce"><IoArrowBackCircleOutline size={30}/></div>}
    </div>
  );
};

export default Page;
