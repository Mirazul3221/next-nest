"use client"
import { NextResponse } from 'next/server'
import { NextRequest } from 'next/server'
import { localstoreToken } from './app/global/tokenAccess'
 
// This function can be marked `async` if using `await` inside
export function middleware(request) {
  console.log(localstoreToken.token)
}
 
// See "Matching Paths" below to learn more
export const config = {
  matcher: '/',
}